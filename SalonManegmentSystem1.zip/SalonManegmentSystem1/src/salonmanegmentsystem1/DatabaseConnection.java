/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package salonmanegmentsystem1;

/**
 *
 * @author acer
 */
import java.sql.*;
public class DatabaseConnection {
     public static Connection getConnection() {
        Connection databaseLink = null;
        // Initializing Database Credentials
        String databaseName = "salonmanegmentsystemSQLL";
        String databaseUser = "root";
        String databasePassword = "root";
        String url = "jdbc:derby://localhost:1527/MSQsalonSystem" + databaseName;

        try {
           
            Class.forName("com.mysql.jdbc.Driver");
            databaseLink = (Connection) DriverManager.getConnection(url, databaseUser, databasePassword);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return databaseLink;
    }
}
