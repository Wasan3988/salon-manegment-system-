/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package salonmanegmentsystem1;


/**
 *
 * @author acer
 * 
 * 
 */
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
public class SalonManeger extends javax.swing.JFrame {

    /**
     * Create
     */
     private String currentUser;
    private Connection db;
    private Statement stmt;
    private ResultSet set;

    public SalonManeger() {
        
        initComponents();
        
        try{
            String URL = "jdbc:derby://localhost:1527/MSQsalonSystem";
            String username = "root";
            String pass = "root";
            
            db = DriverManager.getConnection(URL, username , pass);
            stmt = db.createStatement();
            
           JTable();
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(rootPane, ex.getMessage());
        }
    }
 
public void JTable(){
        try{
            String sql = "SELECT * FROM salon";
            set = stmt.executeQuery(sql);
            
            DefaultTableModel tableMOD = (DefaultTableModel) jTable1.getModel();
            tableMOD.setRowCount(0);

            while(set.next()){
                String salonName = set.getString("salon_name");
                String salonAddres = set.getString("salon_address");
              

                String tbData[] = {salonName,salonAddres};
                tableMOD = (DefaultTableModel) jTable1.getModel();

                tableMOD.addRow(tbData);
            }
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(rootPane, ex.getMessage());
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jBtnDeletSalon = new javax.swing.JButton();
        jaddSalon = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jTextSalonName = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jTextSalonAddress = new javax.swing.JTextField();
        backto = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(236, 220, 220));
        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel1.setFont(new java.awt.Font("Freestyle Script", 0, 70)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(83, 58, 50));
        jLabel1.setText(" Manege Salons ");

        jTable1.setAutoCreateRowSorter(true);
        jTable1.setBackground(new java.awt.Color(226, 200, 199));
        jTable1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jTable1.setFont(new java.awt.Font("Aldhabi", 0, 24)); // NOI18N
        jTable1.setForeground(new java.awt.Color(83, 58, 50));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Salon Name ", "Salon Address"
            }
        ));
        jTable1.setGridColor(new java.awt.Color(171, 124, 115));
        jScrollPane1.setViewportView(jTable1);

        jBtnDeletSalon.setBackground(new java.awt.Color(171, 124, 115));
        jBtnDeletSalon.setFont(new java.awt.Font("Freestyle Script", 0, 24)); // NOI18N
        jBtnDeletSalon.setText("Delet Salon ");
        jBtnDeletSalon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnDeletSalonActionPerformed(evt);
            }
        });

        jaddSalon.setBackground(new java.awt.Color(171, 124, 115));
        jaddSalon.setFont(new java.awt.Font("Freestyle Script", 0, 24)); // NOI18N
        jaddSalon.setText("ADD salon ");
        jaddSalon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jaddSalonActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Freestyle Script", 0, 36)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(83, 58, 50));
        jLabel2.setText("Salon Name :");

        jTextSalonName.setBackground(new java.awt.Color(226, 200, 199));

        jLabel3.setFont(new java.awt.Font("Freestyle Script", 0, 36)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(83, 58, 50));
        jLabel3.setText("Salon Address: ");

        jTextSalonAddress.setBackground(new java.awt.Color(226, 200, 199));

        backto.setBackground(new java.awt.Color(171, 124, 115));
        backto.setFont(new java.awt.Font("Freestyle Script", 0, 24)); // NOI18N
        backto.setText("Back to Mang Page");
        backto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backtoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(backto)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jBtnDeletSalon, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(jLabel3))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jaddSalon, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(jLabel2)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jTextSalonName, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextSalonAddress, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 506, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 448, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(16, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jaddSalon)
                    .addComponent(jLabel2)
                    .addComponent(jTextSalonName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(14, 14, 14)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jTextSalonAddress, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel3))
                    .addComponent(jBtnDeletSalon))
                .addGap(34, 34, 34)
                .addComponent(backto)
                .addContainerGap(71, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jaddSalonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jaddSalonActionPerformed
        // TODO add your handling code here:
        try{
       
            String btnsalonadd = jTextSalonName.getText();
            String btnsalonaddrss = jTextSalonAddress.getText();
        
            
            String sql = "INSERT INTO salon (salon_name,salon_address) VALUES (?,?)";
            PreparedStatement insertStatement = db.prepareStatement(sql);
            
            insertStatement.setString(1, btnsalonadd);
            insertStatement.setString(2, btnsalonaddrss);
     
            
            insertStatement.executeUpdate();
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(rootPane, ex.getMessage());
        }
        
        JTable();
    }//GEN-LAST:event_jaddSalonActionPerformed

    private void jBtnDeletSalonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnDeletSalonActionPerformed
        // TODO add your handling code here:
        try{
            String salonName1 = jTextSalonName.getText();
            
            String sql = "DELETE FROM salon WHERE salon_name = " + salonName1 ;
            stmt.executeUpdate(sql);
            
            JOptionPane.showMessageDialog(rootPane, "Deleted..");
            
            jTextSalonName.setText("");
            jTextSalonAddress.setText("");
         
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(rootPane, ex.getMessage());
        }
        
        JTable();
        
    }//GEN-LAST:event_jBtnDeletSalonActionPerformed

    private void backtoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backtoActionPerformed
           Maneger S = new Maneger();
        S.show();
        this.dispose();  
    }//GEN-LAST:event_backtoActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SalonManeger.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SalonManeger.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SalonManeger.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SalonManeger.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SalonManeger().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backto;
    private javax.swing.JButton jBtnDeletSalon;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextSalonAddress;
    private javax.swing.JTextField jTextSalonName;
    private javax.swing.JButton jaddSalon;
    // End of variables declaration//GEN-END:variables
}
